<?php require_once 'common/header.php'; ?>
	
	<!--Page Title-->
    <!--  -->
    <!--End Page Title-->
		
	<section class="about-section-two text-center">
		<h2 style="margin-bottom: 50px;">WECOME TO IMFI ONLINE TUTORIALS  </h2>
				
		<div class="auto-container">
			<div class="row clearfix">

				<div class="video-column col-lg-6 col-md-12 col-sm-12">
					<div class="inner-column">
						<!--Video Box-->
                        <div class="video-box" style="background-image:url(<?php echo HOME; ?>images/resource/bri5.jpg); background-position: center; background-size: cover;">
                            <figure class="image">
                                <video width="320" height="240" controls>
							  	<source src="<?php echo HOME; ?>uploads/videos/VID-20200507-WA0002.mp4">
							</video>
                            </figure>
                        </div>
							<h3><span style="color: #000;">English Language</span></h3>
							<a class="btn btn-secondary" href="<?php echo HOME; ?>hometeacherform">Register to Downloads</a>
					</div>
				</div>

				<div class="video-column col-lg-6 col-md-12 col-sm-12">
					<div class="inner-column">
						<!--Video Box-->
                        <div class="video-box" style="background-image:url(<?php echo HOME; ?>images/resource/bri4.jpg)">
                            <figure class="image">
                                <!-- <img src="<?php echo HOME; ?>images/resource/video-img.jpg" alt=""> -->
                                <a href=""></a><video width="320" height="240" controls>
							  	<source src="<?php echo HOME; ?>uploads/videos/VID-20200507-WA0003.mp4">
							</video>
                            </figure>
                        </div>
							<h3><span style="color: #000;">Mathematics</span></h3>
							<a class="btn btn-secondary" href="<?php echo HOME; ?>hometeacherform">Register to Downloads</a>
					</div>
				</div>
			</div>			
		</div>
	</section>


	<!--Sponsors Section-->

	
	<!--Main Footer-->

<?php require_once 'common/footer.php'; ?>