<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Studentdomain extends Controller
{
    //
}
